import Achievements from "./_components/AchievementList";

export default function AchievementsPage() {
  return (
    <div className="container mx-auto px-4">
      <Achievements />
    </div>
  );
}